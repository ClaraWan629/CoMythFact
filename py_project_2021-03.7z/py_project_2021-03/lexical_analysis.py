'''
By Clara Mingyu Wan
On 1st April 2021
'''
import sys
import glob
import nltk
from nltk import FreqDist
import string
from nltk.corpus import stopwords
import os
from nltk.corpus import treebank
#import stanfordcorenlp

def load_filecontent(fn):
    text = list(open(fn, "r", encoding='utf-8').readlines())
    text = [s.strip('\n') for s in text]
    return text

def write_list(fn, wlist):
    outfile = open(fn, 'w', encoding='utf-8')
    for line in wlist:
        outfile.write(line + '\n')
    outfile.close()

def write_list_num(fn, wlist):
    outfile = open(fn, 'w', encoding='utf-8')
    for number in wlist:
        outfile.write(str(number) + '\n')
    outfile.close()

def write_dict(fn, dic):
    outfile = open(fn, 'w', encoding='utf-8')
    for key, value in dic.items():
        outfile.write(key + '\t' + value + '\n')
    outfile.close()

def write_tuple(fn, wf):
    outfile = open(fn, 'w', encoding='utf-8')
    for word, freq in wf:
        outfile.write(word + '\t' + str(freq) + '\n')
    outfile.close()

# load the data
input_path = "final_data_raw.txt"
mylines = load_filecontent(input_path)

# get the set of bows
stopWords = set(stopwords.words('english'))
mywords = []
for line in mylines:
    temp = line.split(' ')
    for token in temp:
        token = token.lower()
        if token not in stopWords:
            mywords.append(token.strip(".,;!?-*:'"))
fdist = FreqDist(w for w in mywords)
words_in_rank = fdist.most_common()

#get the bag of words in the entire corpus
words_of_entire_corpus = []
for w,f in words_in_rank:
    words_of_entire_corpus.append(w)

#get the word, freq distribution of facts
# load the data
input_path = "Facts.csv"
facts = load_filecontent(input_path)

# get the set of bows
stopWords = set(stopwords.words('english'))
fact_words = []
for line in facts:
    temp = line.split(' ')
    for token in temp:
        token = token.lower()
        if token not in stopWords:
            fact_words.append(token.strip(".,;!?-*:'"))
fdist1 = FreqDist(w for w in fact_words)
fdist1_fact = fdist1.most_common()
# construct a dictionary of w,f of facts
fact_word_dic = {}
for w,f in fdist1_fact:
    fact_word_dic[w]=f

#print(len(fact_word_dic)) # 8210
#print(fact_word_dic.get("covid-19")) #1868

#get the word, freq distribution of Myths
# load the data
input_path = "Myths.csv"
myths = load_filecontent(input_path)

# get the set of bows
stopWords = set(stopwords.words('english'))
myth_words = []
for line in myths:
    temp = line.split(' ')
    for token in temp:
        token = token.lower()
        if token not in stopWords:
            myth_words.append(token.strip(".,;!?-*:'"))
fdist2 = FreqDist(w for w in myth_words)
fdist2_myth = fdist2.most_common()
# construct a dictionary of w,f of facts
myth_word_dic = {}
for w,f in fdist2_myth:
    myth_word_dic[w]=f

#print(len(myth_word_dic)) # 11843
#print(myth_word_dic.get("covid-19")) #2000

#construct the distribution list for facts
facts_wf_list = []
for word in words_of_entire_corpus:
    facts_wf_list.append(fact_word_dic.get(word))

#construct the distribution list for myths
myths_wf_list = []
for word in words_of_entire_corpus:
    myths_wf_list.append(myth_word_dic.get(word))

##output
#facts
facts_wf_path = 'facts_frequency.txt'
write_list_num(facts_wf_path,facts_wf_list)
#myths
myths_wf_path = 'myths_frequency.txt'
write_list_num(myths_wf_path,myths_wf_list)

print("done.")
#words_freq_path = "words_freq.txt"
#write_tuple(words_freq_path, words_in_rank)
#print("written done.")