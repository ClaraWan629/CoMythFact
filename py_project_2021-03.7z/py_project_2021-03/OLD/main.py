'''
By Clara Mingyu Wan
On 29 March 2021
'''
import sys
import glob
import nltk
from nltk import FreqDist
import string
from nltk.corpus import stopwords
import os
from nltk.corpus import treebank
#import stanfordcorenlp

def load_filecontent(fn):
    text = list(open(fn, "r", encoding='utf-8').readlines())
    text = [s.strip('\n') for s in text]
    return text

def write_list(fn, wlist):
    outfile = open(fn, 'w', encoding='utf-8')
    for line in wlist:
        outfile.write(line + '\n')
    outfile.close()

def write_list_num(fn, wlist):
    outfile = open(fn, 'w', encoding='utf-8')
    for number in wlist:
        outfile.write(str(number) + '\n')
    outfile.close()

def write_dict(fn, dic):
    outfile = open(fn, 'w', encoding='utf-8')
    for key, value in dic.items():
        outfile.write(key + '\t' + value + '\n')
    outfile.close()

def write_tuple(fn, wf):
    outfile = open(fn, 'w', encoding='utf-8')
    for word, freq in wf:
        outfile.write(word + '\t' + str(freq) + '\n')
    outfile.close()

# load the data
input_path = "final_data_raw.txt"
mylines = load_filecontent(input_path)

# pos tagging
#tagged_claims = []
tagged_list = []
for line in mylines:
    tokens = nltk.word_tokenize(line)
    tagged = nltk.pos_tag(tokens)
    tags = []
    for w, t in tagged:
        tags.append(t)
    tagged_list.append(tags)
    #tagged_claims.append(' '.join(tags))

#construct pos feature matrix
pos_tagset = ['CC', 'CD', 'DT', 'EX', 'FW', 'IN', 'JJ', 'JJR', 'JJS', 'LS', 'MD', 'NN', 'NNS', 'NNP', 'NNPS',
              'PDT', 'POS', 'PRP', 'PRP$', 'RB', 'RBR', 'RBS', 'RP', 'SYM', 'TO', 'UH',
              'VB', 'VBD', 'VBG', 'VBN', 'VBP', 'VBZ', 'WDT', 'WP', 'WP$', 'WRB']
pos_feature_array = []
for tags in tagged_list:
    feature_line = []
    for i in range(len(pos_tagset)):
        count = 0
        for t in tags:
            if t==pos_tagset[i]:
                count+=1
        feature_line.append(str(count))
    pos_feature_array.append('\t'.join(feature_line))

out_path = "pos_feature_array.txt"
write_list(out_path, pos_feature_array)
print("done.")




#print(tagged_claims[:5])
#out_path = "tagged.txt"
#write_list(out_path,tagged_claims)
#print("done.")
'''
#testing nltk: good
s = mylines[0]
#print(s)
tokens = nltk.word_tokenize(s)
tagged = nltk.pos_tag(tokens)
print(tagged)
####################stanfordcorenlp在处理大批量数据时会出问题########################
##pos标注语料，提取词类信息频率
# use stanford CoreNLP
# set Java pth - compulsary!
java_path = "C:\Program Files\Java\jre1.8.0_271"
os.environ['JAVAHOME'] = java_path
from stanfordcorenlp import StanfordCoreNLP
nlp = StanfordCoreNLP(r'D://stanford-corenlp-4.2.0', lang='en') #'zh' for Chinese
#print(nlp.parse("hello world."))

# load the data
input_path = "final_data_raw.txt"
mylines = load_filecontent(input_path)

##POS tagging
tagged_claims = []
for line in mylines:
    tagged = nlp.pos_tag(line)
    tagged_claims.append(tagged)

#nlp.close()
print(tagged_claims[:5])


##parsing
parsed_claims = []
for line in mylines:
    parsed = nlp.parse(line)
    parsed_claims.append(parsed)

print(parsed_claims[:2]) #['(ROOT\r\n  (S\r\n    (NP (DT The) (NN COVID-19) (NN Virus))\r\n    (VP\r\n      (VP (VBZ is)\r\n        (VP (VBN spread)\r\n          (ADVP (RBR faster))\r\n          (PP (IN in)\r\n            (NP (JJ cold) (NN environment)))))\r\n      (CC and)\r\n      (VP (VBZ is)\r\n        (VP (VBN killed)\r\n          (PP (IN with)\r\n            (NP\r\n              (ADJP (JJ hot)\r\n                (CC and)\r\n                (JJ humid))\r\n              (NN environment))))))\r\n    (. .)))', '(ROOT\r\n  (S\r\n    (S\r\n      (NP (DT The) (NN COVID-19) (NN Virus))\r\n      (VP (VBZ is)\r\n        (VP (VBN transmitted)\r\n          (PP (IN by)\r\n            (NP (NNPS Mosquitoes)))))\r\n      (VP (VBZ bites)))\r\n    (. .)))']
#parsed_path = 'parsed_claims.txt'
#write_list(parsed_path, parsed_claims)

#for claim in parsed_claims:
    #for x in claim:
        #print(x)

#PP_count_index = []
#ADJP_count_index = []
VP_count_index = []
NP_count_index = []
ADVP_count_index = []
for claim in parsed_claims:
    #PP_count = 0
    #ADJP_count = 0
    VP_count = 0
    NP_count = 0
    ADVP_count = 0
    nodes = claim.split('\r\n')
    for line in nodes:
        #if '(PP' in line:
        #PP_count += 1
        #elif '(ADJP' in line:
        #ADJP_count += 1
        if '(VP' in line:
            VP_count += 1
        elif '(NP' in line:
            NP_count += 1
        elif '(ADVP' in line:
            ADVP_count += 1
        #PP_count_index.append(PP_count)
        #ADJP_count_index.append(ADJP_count)
    VP_count_index.append(VP_count)
    NP_count_index.append(NP_count)
    ADVP_count_index.append(ADVP_count)

#print(PP_count_index[:10]) #[2, 1, 1, 0, 0, 1, 1, 2, 0, 0]
#PP_out_path = 'PP.txt'
#ADJP_out_path = 'ADJP.txt'
VP_out_path = 'VP.txt'
ADVP_out_path = 'ADVP.txt'
NP_out_path = 'NP.txt'

#write_list_num(PP_out_path, PP_count_index)
#write_list_num(ADJP_out_path, ADJP_count_index)
write_list_num(VP_out_path, VP_count_index)
write_list_num(NP_out_path, NP_count_index)
write_list_num(ADVP_out_path, ADVP_count_index)

print('done.')

##基本数据，词长 句长 TTR 等
#load data
input_path = "final_data_raw.txt"
mylines = load_filecontent(input_path)

# word.length in average and sentence.length for each claim
word_len_index = []
sent_len_index = []
token_index = []
type_index = []

for line in mylines:
    words = line.split(' ')
    no_words = len(words)
    token_index.append(no_words)
    types = set(words)
    no_type = len(types)
    type_index.append(no_type)
    sent_len_index.append(no_words) # sentence length
    w_len = 0
    for w in words:
        w_len += len(w)
    w_len_avg = w_len / no_words
    word_len_index.append(w_len_avg)
print(word_len_index[:5]) #[5.166666666666667, 5.8, 6.666666666666667, 6.230769230769231, 4.3125]
print(sent_len_index[:5]) #[12, 10, 6, 13, 16]

#write to a file
word_len_path = "word_length_avg.txt"
write_list_num(word_len_path,word_len_index)

sent_len_path = "sent_length.txt"
write_list_num(sent_len_path,sent_len_index)

token_path = "token.txt"
write_list_num(token_path,token_index)

type_path = "type.txt"
write_list_num(type_path,type_index)

print('done.')


##去掉问句，去掉乱码
#load data
input_path = "merged_data_original.txt"
mylines = load_filecontent(input_path)

punctuations = string.punctuation # punctuation set
alphabets = string.ascii_lowercase + string.ascii_uppercase # alphabet list
numbers = "0123456789"
right_codes = punctuations + alphabets + numbers + ' ' + '\t'

#print(punctuations) #!"#$%&'()*+,-./:;<=>?@[\]^_`{|}~
#print(alphabets) #abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ

#print(right_codes) #!"#$%&'()*+,-./:;<=>?@[\]^_`{|}~abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789
selected_claims = []
for line in mylines:
    wrong_code = 0
    for ch in line:
        if ch not in right_codes:
            wrong_code = 1
            break
    if line.find("?")<=-1 and wrong_code == 0:
        selected_claims.append(line)

#print(len(selected_claims))
#print(selected_claims[90:100])

#write data
out_path = "Merged_data_clean.txt"
write_list(out_path,selected_claims)
print('done.')


##1. select false claims from COVID-19 MISINFO
#load data
input_path = "COVID-19 MISINFO.txt"
mylines = load_filecontent(input_path)

#save the lines with "False Claim"
#print(mylines[:20])
False_Claims = []
for line in mylines:
    if line.find("False Claim")>-1:
        line=line.replace("    False Claim : ", "")
        False_Claims.append(line)

#print(len(False_Claims)) #547
#print(False_Claims[:5]) #['Doctors and nurses who administer the coronavirus vaccine can be "tried as war criminals."',

#write data
out_path = "FalseClaimsMisinfo.txt"
write_list(out_path,False_Claims)
print('done.')

##判断空串并输出indexes
empty_index =[]
i=0
for line in mylines:
    if len(line)<=0 or line == " ":
        empty_index.append(i)
    i=+1

print(empty_index)
'''

