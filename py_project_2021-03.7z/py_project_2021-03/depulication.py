'''
By Clara Mingyu Wan
On 4 April 2021
'''
import sys
import glob
import nltk
from nltk import FreqDist
import string
from nltk.corpus import stopwords
import os
from nltk.corpus import treebank
#import stanfordcorenlp
import random

def load_filecontent(fn):
    text = list(open(fn, "r", encoding='utf-8').readlines())
    text = [s.strip('\n') for s in text]
    return text

def write_list(fn, wlist):
    outfile = open(fn, 'w', encoding='utf-8')
    for line in wlist:
        outfile.write(line + '\n')
    outfile.close()

def write_list_num(fn, wlist):
    outfile = open(fn, 'w', encoding='utf-8')
    for number in wlist:
        outfile.write(str(number) + '\n')
    outfile.close()

def write_dict(fn, dic):
    outfile = open(fn, 'w', encoding='utf-8')
    for key, value in dic.items():
        outfile.write(key + '\t' + value + '\n')
    outfile.close()

def write_tuple(fn, wf):
    outfile = open(fn, 'w', encoding='utf-8')
    for word, freq in wf:
        outfile.write(word + '\t' + str(freq) + '\n')
    outfile.close()

# load the data
input_path = "Facts_Final.txt"
mylines = load_filecontent(input_path)

#randomlist = random.sample(range(1, 7000), 5010)
#print(randomlist[200:220])

#myths_final = []
#for x in randomlist:
   #myths_final.append(mylines[x])

#myths_final = set(myths_final) # deduplication
facts_final = set(mylines) # deduplication
#output
out_path = "Facts_final_deduplication.txt"
write_list(out_path, facts_final)
print("done.")

